can_access = False

if can_access is False:
    print("No access!")
