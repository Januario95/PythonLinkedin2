class Command:


class Copy(Command):


class Paste(Command):
	def execute(self):
		print("Pasting ...")

class Save(Command):
	def execute(self):
		print("Saving ...")

class Macro:
	def __init__(self):
		

	def add(self, command):
		

	def run(self):
		

def main():


if __name__ == "__main__":
	main()
