import pickle

class Originator:

	def __init__(self):
			

	def create_memento(self):
		

	def set_memento(self, memento):
		

def main():
	
	

if __name__ == "__main__":
	main()
