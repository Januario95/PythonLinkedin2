

class AbstractExpression():

	

class NonterminalExpression(AbstractExpression):

	def __init__(self, expression):
			

	def interpret(self):
		print("Non-terminal expression being interpreted ...")
		

class TerminalExpression(AbstractExpression):

	def interpret(self):
		print("Terminal expression being interpreted ...")

def main():
	
	

if __name__ == "__main__":
	main()
